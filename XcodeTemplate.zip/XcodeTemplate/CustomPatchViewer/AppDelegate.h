//
//  AppDelegate.h
//  CustomPatchViewer
//
//  Created by Max Weisel on 11/19/15.
//  Copyright © 2015 Max Weisel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

