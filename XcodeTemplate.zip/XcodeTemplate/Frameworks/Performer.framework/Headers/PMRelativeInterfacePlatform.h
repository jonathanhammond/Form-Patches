//
//  PMRelativeInterfacePlatform.h
//  Performer
//
//  Created by ederle on 6/24/15.
//  Copyright (c) 2015 Relative Wave. All rights reserved.
//

#if TARGET_OS_IPHONE
#import <RelativeInterface/RelativeInterface.h>
#elif TARGET_OS_MAC
#import <RelativeInterfaceMac/RelativeInterfaceMac.h>
#endif
