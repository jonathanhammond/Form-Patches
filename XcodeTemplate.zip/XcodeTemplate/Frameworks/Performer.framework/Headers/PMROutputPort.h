//
//  PMROutputPort.h
//  Performer
//
//  Created by Max Weisel on 6/24/14.
//  Copyright (c) 2014 Relative Wave. All rights reserved.
//

#import "PMRPort.h"

@interface PMROutputPort : PMRPort

- (void)setNeedsProcessing;

@end
