//
//  RICoreGraphicsView.h
//  RelativeInterface
//
//  Created by Max Weisel on 6/15/14.
//  Copyright (c) 2014 RelativeWave. All rights reserved.
//

#import "RIView.h"

@interface RICoreGraphicsView : RIView

@end
