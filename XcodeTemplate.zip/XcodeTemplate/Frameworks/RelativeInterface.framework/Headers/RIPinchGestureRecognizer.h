//
//  RIPinchGestureRecognizer.h
//  RelativeInterface
//
//  Created by Max Weisel on 3/6/14.
//  Copyright (c) 2014 RelativeWave. All rights reserved.
//

#import "RIGestureRecognizer.h"

@interface RIPinchGestureRecognizer : RIGestureRecognizer

@property (nonatomic, assign) float scale;

@end
