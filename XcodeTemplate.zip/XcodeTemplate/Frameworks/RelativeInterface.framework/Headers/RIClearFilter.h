//
//  RIClearFilter.h
//  RelativeInterface
//
//  Created by Max Weisel on 2/13/15.
//  Copyright (c) 2015 RelativeWave. All rights reserved.
//

#import "RIFilter.h"

@interface RIClearFilter : RIFilter

@end
