//
//  RIRotationGestureRecognizer.h
//  RelativeInterface
//
//  Created by Max Weisel on 5/19/14.
//  Copyright (c) 2014 RelativeWave. All rights reserved.
//

#import "RIGestureRecognizer.h"

@interface RIRotationGestureRecognizer : RIGestureRecognizer

@property (nonatomic, assign) float rotation;
//@property (nonatomic, readonly) float velocity;

@end
