//
//  RIImageTypes.h
//  RelativeInterface
//
//  Created by Max Weisel on 12/12/13.
//  Copyright (c) 2013 RelativeWave. All rights reserved.
//

@class RIImage;

typedef void (^RIImageCompletionBlock)(RIImage *image, BOOL success);
